import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import Header from './components/Header.jsx';
import Hero from './components/Hero.jsx';
import Features from './components/Features.jsx';
import HowToUse from './components/HowToUse.jsx';
import Footer from './components/Footer.jsx';

const content = {
  en: {
    navigation: 'Main navigation', home: 'Home', about: 'About', language: 'Choose language',
    eyebrow: 'A simpler way to save for later', title: 'Download TikTok', titleAccent: 'Videos',
    subtitle: 'A straightforward place to start with a TikTok link. Paste it below and see how the workflow will feel — downloading is not available just yet.',
    urlLabel: 'TikTok video link', urlHint: 'Paste a public video URL', placeholder: 'https://www.tiktok.com/@creator/video/…',
    paste: 'Paste', clear: 'Clear', download: 'Download', comingSoon: 'Downloading is coming soon. This button is not active yet.',
    pasted: 'Link pasted from clipboard.', clipboardEmpty: 'Your clipboard is empty.', clipboardBlocked: 'Clipboard access is unavailable. Paste the link into the field instead.',
    previewArea: 'Video preview and results placeholders', videoPreview: 'Video preview', videoPreviewHint: 'Your linked video will appear here later', results: 'Download options',
    featuresKicker: 'Made to feel effortless', featuresTitle: 'The useful bits, without the clutter.', featuresIntro: 'Zhae Gio keeps the idea simple: one link, a clear flow, and no extra steps to figure out.',
    features: [
      { title: 'Easy to use', description: 'A clean link field and familiar controls. Nothing to learn before you begin.' },
      { title: 'Designed for speed', description: 'A lightweight flow with processing speed in mind, once downloads arrive.' },
      { title: 'Ready for mobile', description: 'A responsive layout that feels natural on a phone, tablet, or desktop.' },
      { title: 'Just the essentials', description: 'No busy dashboards or confusing settings. Just the task at hand.' },
    ],
    howKicker: 'Three small steps', howTitle: 'Link in. Video out.', howIntro: 'The full workflow is being built. Here is the simple path Zhae Gio is designed to offer when it is ready.',
    steps: [
      { title: 'Copy a TikTok link', description: 'Find a video you want to keep and copy its share link from TikTok.' },
      { title: 'Paste it into Zhae Gio', description: 'Add the public video URL to the field above. The preview and options will be shown here in a future phase.' },
      { title: 'Choose your download', description: 'When downloading is available, you will be able to review the result and save it to your device.' },
    ],
    phaseOneTitle: 'Phase 1 preview', phaseOneText: 'The downloader interface is here to show the planned experience. No video is processed or downloaded yet.',
    footerLine: 'A small, clear tool for a link-first workflow.', footerNavigation: 'Footer links', privacy: 'Privacy Policy', terms: 'Terms of Service',
    copyright: `© ${new Date().getFullYear()} Zhae Gio. All rights reserved.`,
    legalPrivacy: 'A full privacy policy has not been published yet. This Phase 1 page does not send your link to a server or process it. Clipboard access is only used when you choose Paste.',
    legalTerms: 'Terms of Service will be published when downloading becomes available. For now, Zhae Gio is a non-functional preview; no videos are downloaded or processed.',
    legalLabel: 'Information', legalClose: 'Close',
  },
  es: {
    navigation: 'Navegación principal', home: 'Inicio', about: 'Acerca de', language: 'Elegir idioma',
    eyebrow: 'Una forma más sencilla de guardar', title: 'Descarga videos de', titleAccent: 'TikTok',
    subtitle: 'Un punto de partida sencillo para usar un enlace de TikTok. Pégalo abajo y descubre el flujo previsto; la descarga todavía no está disponible.',
    urlLabel: 'Enlace del video de TikTok', urlHint: 'Pega la URL de un video público', placeholder: 'https://www.tiktok.com/@creador/video/…',
    paste: 'Pegar', clear: 'Borrar', download: 'Descargar', comingSoon: 'La descarga llegará pronto. Este botón todavía no está activo.',
    pasted: 'Enlace pegado desde el portapapeles.', clipboardEmpty: 'El portapapeles está vacío.', clipboardBlocked: 'No se puede acceder al portapapeles. Pega el enlace en el campo.',
    previewArea: 'Espacios para la vista previa y los resultados', videoPreview: 'Vista previa del video', videoPreviewHint: 'El video enlazado aparecerá aquí más adelante', results: 'Opciones de descarga',
    featuresKicker: 'Diseñado para ser sencillo', featuresTitle: 'Lo esencial, sin distracciones.', featuresIntro: 'Zhae Gio mantiene la idea simple: un enlace, un flujo claro y ningún paso extra que descifrar.',
    features: [
      { title: 'Fácil de usar', description: 'Un campo de enlace claro y controles conocidos. Empieza sin tener que aprender nada.' },
      { title: 'Diseñado para la rapidez', description: 'Un flujo ligero pensado para procesar rápido cuando las descargas estén disponibles.' },
      { title: 'Listo para móviles', description: 'Un diseño adaptable que funciona naturalmente en teléfono, tableta o computadora.' },
      { title: 'Solo lo necesario', description: 'Sin paneles recargados ni ajustes confusos. Solo la tarea que necesitas.' },
    ],
    howKicker: 'Tres pasos sencillos', howTitle: 'Enlace adentro. Video listo.', howIntro: 'Estamos desarrollando el flujo completo. Este es el camino sencillo que Zhae Gio ofrecerá cuando esté listo.',
    steps: [
      { title: 'Copia un enlace de TikTok', description: 'Busca un video que quieras guardar y copia su enlace para compartir desde TikTok.' },
      { title: 'Pégalo en Zhae Gio', description: 'Añade la URL pública del video en el campo de arriba. La vista previa y las opciones llegarán en una fase futura.' },
      { title: 'Elige tu descarga', description: 'Cuando esté disponible, podrás revisar el resultado y guardarlo en tu dispositivo.' },
    ],
    phaseOneTitle: 'Vista previa de fase 1', phaseOneText: 'La interfaz muestra la experiencia prevista. Todavía no se procesa ni se descarga ningún video.',
    footerLine: 'Una herramienta sencilla para trabajar con enlaces.', footerNavigation: 'Enlaces del pie de página', privacy: 'Política de privacidad', terms: 'Términos del servicio',
    copyright: `© ${new Date().getFullYear()} Zhae Gio. Todos los derechos reservados.`,
    legalPrivacy: 'La política de privacidad completa aún no se ha publicado. Esta página de fase 1 no envía tu enlace a un servidor ni lo procesa. El portapapeles solo se usa cuando eliges Pegar.',
    legalTerms: 'Los términos del servicio se publicarán cuando las descargas estén disponibles. Por ahora, Zhae Gio es una vista previa sin funcionalidad; no se descargan ni procesan videos.',
    legalLabel: 'Información', legalClose: 'Cerrar',
  },
};

function App() {
  const [lang, setLang] = useState('en');
  const [legal, setLegal] = useState(null);
  const copy = content[lang];

  useEffect(() => {
    if (!legal) return undefined;
    function closeOnEscape(event) {
      if (event.key === 'Escape') setLegal(null);
    }
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, [legal]);

  return (
    <div className="page-shell">
      <Header lang={lang} setLang={setLang} copy={copy} />
      <main>
        <Hero copy={copy} />
        <Features copy={copy} />
        <HowToUse copy={copy} />
      </main>
      <Footer copy={copy} onLegal={setLegal} />
      {legal && (
        <div className="legal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setLegal(null); }}>
          <section className="legal-dialog" role="dialog" aria-modal="true" aria-labelledby="legal-title">
            <button className="legal-close" type="button" onClick={() => setLegal(null)} aria-label={copy.legalClose} data-testid="button-close-legal"><X /></button>
            <span className="section-kicker">{copy.legalLabel}</span>
            <h2 id="legal-title" data-testid="heading-legal-dialog">{legal === 'privacy' ? copy.privacy : copy.terms}</h2>
            <p>{legal === 'privacy' ? copy.legalPrivacy : copy.legalTerms}</p>
          </section>
        </div>
      )}
    </div>
  );
}

export default App;
