import { useState } from 'react';
import { ClipboardPaste, Link2, Image, ListChecks, ShieldCheck, X } from 'lucide-react';

export default function Downloader({ copy }) {
  const [url, setUrl] = useState('');
  const [pasteMessage, setPasteMessage] = useState('');

  async function pasteFromClipboard() {
    try {
      if (!navigator.clipboard?.readText) throw new Error('Clipboard unavailable');
      const text = await navigator.clipboard.readText();
      if (text) {
        setUrl(text.trim());
        setPasteMessage(copy.pasted);
      } else {
        setPasteMessage(copy.clipboardEmpty);
      }
    } catch {
      setPasteMessage(copy.clipboardBlocked);
    }
  }

  function clearUrl() {
    setUrl('');
    setPasteMessage('');
  }

  return (
    <>
      <div className="downloader-panel">
        <div className="input-topline">
          <label htmlFor="video-url">{copy.urlLabel}</label>
          <span className="input-hint">{copy.urlHint}</span>
        </div>
        <input
          id="video-url"
          data-testid="input-video-url"
          className="url-field"
          type="url"
          inputMode="url"
          autoComplete="url"
          placeholder={copy.placeholder}
          value={url}
          onChange={(event) => { setUrl(event.target.value); setPasteMessage(''); }}
          aria-describedby="availability-note paste-feedback"
        />
        <div className="input-actions">
          <button className="button button-quiet" type="button" onClick={pasteFromClipboard} data-testid="button-paste-url">
            <ClipboardPaste aria-hidden="true" />{copy.paste}
          </button>
          <button className="button button-quiet" type="button" onClick={clearUrl} disabled={!url} data-testid="button-clear-url">
            <X aria-hidden="true" />{copy.clear}
          </button>
          <button className="button button-primary" type="button" disabled aria-disabled="true" data-testid="button-download-video">
            <ArrowIcon />{copy.download}
          </button>
        </div>
        <p className="availability-note" id="availability-note" data-testid="text-download-status">
          <ShieldCheck aria-hidden="true" />{copy.comingSoon}
        </p>
        <p id="paste-feedback" className="sr-only" aria-live="polite">{pasteMessage}</p>
      </div>
      <div className="workspace-preview" aria-label={copy.previewArea}>
        <div className="preview-box">
          <span className="preview-symbol"><Image aria-hidden="true" /></span>
          <strong data-testid="text-video-preview">{copy.videoPreview}</strong>
          <p>{copy.videoPreviewHint}</p>
        </div>
        <div className="preview-box preview-results">
          <div className="results-title">
            <span className="preview-symbol"><ListChecks aria-hidden="true" /></span><span data-testid="text-download-results">{copy.results}</span>
          </div>
          <div className="result-line" />
          <div className="result-line short" />
        </div>
      </div>
    </>
  );
}

function ArrowIcon() {
  return <Link2 aria-hidden="true" />;
}
