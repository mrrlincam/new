import { CircleHelp } from 'lucide-react';

export default function HowToUse({ copy }) {
  return (
    <section className="how-section" id="how-it-works">
      <div className="container how-layout">
        <div className="how-intro">
          <span className="section-kicker">{copy.howKicker}</span>
          <h2>{copy.howTitle}</h2>
          <p>{copy.howIntro}</p>
          <div className="coming-strip">
            <span className="coming-icon"><CircleHelp aria-hidden="true" /></span>
            <div><strong>{copy.phaseOneTitle}</strong><p>{copy.phaseOneText}</p></div>
          </div>
        </div>
        <div className="steps">
          {copy.steps.map((step, index) => {
            return (
              <article className="step" key={step.title}>
                <span className="step-number">0{index + 1}</span>
                <div><h3>{step.title}</h3><p>{step.description}</p></div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
