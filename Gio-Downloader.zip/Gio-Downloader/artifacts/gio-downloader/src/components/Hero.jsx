import Downloader from './Downloader.jsx';

export default function Hero({ copy }) {
  return (
    <section className="hero" id="home">
      <div className="container">
        <div className="hero-copy">
          <div className="hero-eyebrow"><span />{copy.eyebrow}</div>
          <h1>{copy.title}<br /><em>{copy.titleAccent}</em></h1>
          <p>{copy.subtitle}</p>
        </div>
        <div id="downloader">
          <Downloader copy={copy} />
        </div>
      </div>
    </section>
  );
}
