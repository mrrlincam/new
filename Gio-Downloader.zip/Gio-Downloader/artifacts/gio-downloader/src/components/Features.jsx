import { MousePointer2, Gauge, Smartphone, Sparkles } from 'lucide-react';

const icons = [MousePointer2, Gauge, Smartphone, Sparkles];

export default function Features({ copy }) {
  return (
    <section className="features-section" id="about">
      <div className="container">
        <div className="section-heading">
          <span className="section-kicker">{copy.featuresKicker}</span>
          <h2>{copy.featuresTitle}</h2>
          <p>{copy.featuresIntro}</p>
        </div>
        <div className="feature-grid">
          {copy.features.map((feature, index) => {
            const Icon = icons[index];
            return (
              <article className="feature-card" key={feature.title}>
                <span className="feature-icon"><Icon aria-hidden="true" /></span>
                <h3>{feature.title}</h3>
                <p>{feature.description}</p>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
