import { ArrowDownToLine } from 'lucide-react';

export default function Header({ lang, setLang, copy }) {
  return (
    <header className="site-header">
      <div className="container header-inner">
        <a className="brand" href="#home" aria-label="Zhae Gio home" data-testid="link-brand-home">
          <span className="brand-mark"><ArrowDownToLine aria-hidden="true" /></span>
          <span>Zhae <span style={{ color: '#7446d2' }}>Gio</span></span>
        </a>
        <nav className="nav-links" aria-label={copy.navigation}>
          <a href="#home" data-testid="link-home">{copy.home}</a>
          <a href="#about" data-testid="link-about">{copy.about}</a>
        </nav>
        <label className="sr-only" htmlFor="language-choice">{copy.language}</label>
        <select
          id="language-choice"
          className="language-select"
          value={lang}
          onChange={(event) => setLang(event.target.value)}
          aria-label={copy.language}
          data-testid="select-language"
        >
          <option value="en">EN</option>
          <option value="es">ES</option>
        </select>
      </div>
    </header>
  );
}
