import { ArrowDownToLine } from 'lucide-react';

export default function Footer({ copy, onLegal }) {
  return (
    <footer className="site-footer">
      <div className="container">
        <div className="footer-main">
          <div className="footer-brand-wrap">
            <a className="brand" href="#home" aria-label="Zhae Gio home" data-testid="link-footer-brand">
              <span className="brand-mark"><ArrowDownToLine aria-hidden="true" /></span>
              <span>Zhae <span style={{ color: '#7446d2' }}>Gio</span></span>
            </a>
            <p>{copy.footerLine}</p>
          </div>
          <nav className="footer-links" aria-label={copy.footerNavigation}>
            <a href="#about" data-testid="link-footer-about">{copy.about}</a>
            <button type="button" onClick={() => onLegal('privacy')} data-testid="button-privacy-policy">{copy.privacy}</button>
            <button type="button" onClick={() => onLegal('terms')} data-testid="button-terms-of-service">{copy.terms}</button>
          </nav>
        </div>
        <div className="copyright">{copy.copyright}</div>
      </div>
    </footer>
  );
}
